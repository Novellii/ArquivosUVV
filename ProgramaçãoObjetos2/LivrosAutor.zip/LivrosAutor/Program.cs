﻿

using Microsoft.Data.SqlClient;



namespace LivrosAutor // Note: actual namespace depends on the project name.
{
    internal class Program
    {
        private static void Salvar(Autor autor, SqlConnection conexao)
        {
            Console.WriteLine("\n == Salvando o Autor ==");

            var Cmd = conexao.CreateCommand();
            Cmd.CommandText = "INSERT INTO AUTOR (Nome) VALUES (@nome)";

            var param = new SqlParameter("nome", autor.Nome);
            Cmd.Parameters.Add(param);

            Cmd.ExecuteNonQuery();
        }
        static void Main(string[] args)
        {
            SqlConnection? sqlConnectin = null;

            string URL = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=DBAutorLivro;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";

            try
            {
                sqlConnectin = new(URL);
                sqlConnectin.Open();
                Console.WriteLine("OK!");
            }
            catch (Exception ex) 
            { 
                Console.WriteLine("NOT OK");
                Console.WriteLine(ex);
            }

            if (sqlConnectin != null) 
            { 
                Autor autor = new ("Samira");
                Salvar(autor, sqlConnectin);
            }

            sqlConnectin?.Close();
        }
    }
}