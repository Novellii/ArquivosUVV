﻿using antigoDoumentoMicrosoftWord.Control;
using antigoDoumentoMicrosoftWord.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace antigoDoumentoMicrosoftWord.View
{
    /// <summary>
    /// Lógica interna para ConsultaJanela.xaml
    /// </summary>
    public partial class ConsultaJanela : Window
    {
        private IdeiaInovadoraControle objClasseIdeiaInovacao = new();
        private BindingList<IdeiaInovadora> objClasseListDataGridIdeiaInovacao = new();
        public ConsultaJanela()
        {
            InitializeComponent();
            DataGridIndeiaInovacao.ItemsSource = objClasseListDataGridIdeiaInovacao;
        }

        private void DataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Consultar(object sender, RoutedEventArgs e)
        {
            List<IdeiaInovadora>? DadosRecuperados = null;

            if (string.IsNullOrEmpty(TextBoxRecuperar.Text)) 
            {
                DadosRecuperados = objClasseIdeiaInovacao.ControleRecuperarTodasIdeiasInovacao();
            }

            if (DadosRecuperados != null) {
                objClasseListDataGridIdeiaInovacao = new(DadosRecuperados);
                DataGridIndeiaInovacao.ItemsSource = objClasseListDataGridIdeiaInovacao;
            }
        }
    }
}
