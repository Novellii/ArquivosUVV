﻿using antigoDoumentoMicrosoftWord.Control;
using antigoDoumentoMicrosoftWord.Model;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace antigoDoumentoMicrosoftWord
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private IdeiaInovadoraControle objIdeiaInovadoraControle = new();
        public MainWindow()
        {
            MessageBox.Show("Não me deixe te avisar.");
            InitializeComponent();
        }

        private void Clicar(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(AtuacaoBox.Text) && !string.IsNullOrEmpty(IdeiaBox.Text) && !string.IsNullOrEmpty(CustoBox.Text)) {
                if (objIdeiaInovadoraControle.ControleCadastroInovadora(AtuacaoBox.Text, IdeiaBox.Text, float.Parse(CustoBox.Text)))
                {
                    MessageBox.Show("Você não foi avisado.");
                }
            }
            else
            {
                MessageBox.Show("Você foi avisado.");
            }
        }
    }
}