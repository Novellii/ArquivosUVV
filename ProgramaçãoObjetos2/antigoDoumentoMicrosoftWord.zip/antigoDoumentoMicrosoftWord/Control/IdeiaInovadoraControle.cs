﻿using antigoDoumentoMicrosoftWord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace antigoDoumentoMicrosoftWord.Control
{
    internal class IdeiaInovadoraControle
    {
        private IdeiaInovadora ModeloPersistencia = new();
        public Boolean ControleCadastroInovadora(string area, string ideia, float custo) {
            ideia = ideia + "!!!!";

            IdeiaInovadora ideiaInovadora = new()
            {
                Area = area,
                Ideia = ideia,
                Custo = custo
            };

            if (ModeloPersistencia.CadastrarIdeiaInovacao(ideiaInovadora))
            {
                return true;
            }
            return false;
        }
    }
}
