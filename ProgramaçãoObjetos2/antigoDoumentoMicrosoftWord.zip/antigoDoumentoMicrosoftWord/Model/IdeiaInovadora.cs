﻿using antigoDoumentoMicrosoftWord.Persistencs;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace antigoDoumentoMicrosoftWord.Model
{
    internal class IdeiaInovadora
    {
        public int IdIdeiaInovacao { get; set; } = 0;
        public string Area { get; set; }
        public string Ideia { get; set; }
        public float Custo { get; set; }
        public List<IdeiaInovadora> RecuperarTodasIdeiasInovadoras()
        {
            return BD.RetomarBD();
        }

        public IdeiaInovadora RecuperarIdeiaInovacaoPeloId (int id)
        {
            return null;
        }

        public override string ToString()
        {
            return $"{Area} | {Ideia} | {Custo}";
        }

        public Boolean CadastrarIdeiaInovacao(IdeiaInovadora i) 
        {
            BD.SalvarBD(i);
            return true; 
        }
    }
}
