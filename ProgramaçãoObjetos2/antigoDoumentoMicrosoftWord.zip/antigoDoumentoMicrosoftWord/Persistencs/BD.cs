﻿using antigoDoumentoMicrosoftWord.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace antigoDoumentoMicrosoftWord.Persistencs
{
    internal class BD
    {
        public static int IndexGlobal { get; set; }
        public static List<IdeiaInovadora> mybd = new();

        public static void SalvarBD(IdeiaInovadora i)
        { 
            if (i.IdIdeiaInovacao == 0)
            {
                i.IdIdeiaInovacao = ++IndexGlobal;
                mybd.Add(i);
            }
        }

        public static List<IdeiaInovadora> RetomarBD() 
        {
            return mybd;    
        }

        public static IdeiaInovadora RetornaBD(int id) 
        {
            IdeiaInovadora? objRec = null;           // Coloca essa porra de ? pra ele não reclamar do nulo e dar bosta figurativamente
            mybd.Find(objIdeia_r => 
            { 
                return objIdeia_r.IdIdeiaInovacao == id; 
            }
            );
            return objRec;
        }

        private static Boolean VerificarSeExiste(int id)
        {
            return mybd.Exists(objIdeia_e => 
            { 
                return objIdeia_e.IdIdeiaInovacao == id; 
            }
            );
        }
    }
}
