﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkestCombat.mainclasses
{
    internal class Vendedor
    {
        private List<Itens> itensVendidos;
        private Entidade jogador;

        public Vendedor(string nome)
        {
            itensVendidos = new List<Itens>();
        }

        public void ImprimirItems()
        {
            foreach (var iV in itensVendidos)
            {
                iV.PrintarCodigo();
            }
        }
    }
}
