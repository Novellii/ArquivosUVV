﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DarkestCombat.mainclasses
{
    internal class Entidade : Sistema
    {
        public string nome { set; get; }
        public int vidaMaxima { set; get; }
        public int vidaAtual { set; get; }
        public int Constituicao { set; get; }
        public int moedas { set; get; }
        public int classeArmadura { set; get; }

        public List<Armas> armasList;
        public Armas armaEquipada;

            public Entidade(string nome, int vidaValor, int vidaDado, int Constituicao, int moedas, int classeArmadura)
            {
                this.nome = nome;
                this.vidaMaxima = RolarVida(vidaValor, vidaDado, Constituicao);
                this.vidaAtual = vidaMaxima;
                this.Constituicao = Constituicao;
                this.moedas = euroDolar;
                this.classeArmadura = 10;
                armasList = new List<Armas>();
            }

            public Entidade(string nome)
            {
                this.nome = nome;
                armasList = new List<Armas>();
            }

            public void TomarDano(int DMG)
            {
                this.vidaAtual = vidaAtual - DMG;
            }

            public void ImprimirInformacoesArmas()
            {
                foreach (var l in armasList)
                {
                    l.PrintarValores();
                }
            }

            public int RolarVida(int vidaValor, int vidaDado, int Constituicao)
            {
                return RolarDado(vidaDado, vidaValor, Constituicao, false, false);
            }

            public void AdicionarArma(Armas a)
            {
                armasList.Add(a);
            }

            public void EquiparArma(Armas a)
            {
                this.armaEquipada = a;
            }


}
}
