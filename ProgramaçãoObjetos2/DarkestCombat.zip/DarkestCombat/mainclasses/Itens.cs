﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace DarkestCombat.mainclasses
{
    internal class Itens
    {
        public String nomeItem { get; set; }
        public int moedas { get; set; }
        public static int contador = 0;
        public int codigoItem { get; set; }
        public Itens(String nomeItem, int moedas)
        {
            this.nomeItem = nomeItem;
            this.moedas = moedas;
            contador++;
            codigoItem = contador;
        }

        public void PrintarCodigo()
        {
            MessageBox.Show("[#" + codigoItem + "] - " + nomeItem);
        }
    }
}
