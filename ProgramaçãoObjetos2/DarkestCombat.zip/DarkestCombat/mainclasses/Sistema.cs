﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace DarkestCombat.mainclasses
{
    internal class Sistema
    {
        public int RolarDado(int quantidade, int valor, int soma, bool isATK, bool isDMG)
        {
            int i, resultado;
            Random random = new Random();
            for (i = 0; i < quantidade; i++)
            {
                resultado = random.Next(0, valor);
                soma += resultado;
            }
            if (isATK == true)
            {
                MessageBox.Show("O valor da rolagem é " + soma);
            }
            return soma;
        }
    }
}
