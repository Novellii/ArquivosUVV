﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCatch
{
    internal class Aluno
    {
        public string Nome { get; set; } = "";
        public float NotaFinal { get; set; }
        public int NumeroMatricula { get; set; }

        public Aluno(string nome, float notaFinal, int numeroMatricula)
        {
            Nome = nome;
            NotaFinal = notaFinal;
            NumeroMatricula = numeroMatricula;
        }
    }
}
