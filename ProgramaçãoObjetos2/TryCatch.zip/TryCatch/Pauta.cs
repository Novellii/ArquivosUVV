﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryCatch
{
    internal class Pauta
    {
        public List<Aluno> listaAlunos = new List<Aluno>();

        public void addAlunos(Aluno aluno)
        {
            listaAlunos.Add(aluno);
        }

        public void verificaStatus()
        {
            foreach (var aluno in listaAlunos)
            {
                if (aluno.NotaFinal < 7)
                {
                    throw new NotProvaFinalException(aluno);
                }
            }
        }




    }
}
