﻿using System;
using TryCatch;

namespace MyApp 
{
    internal class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Aluno aluno1 = new Aluno("Raquel", 10, 202302478);
                Aluno aluno2 = new Aluno("João", 9, 202302479);
                Aluno aluno3 = new Aluno("Maria", 8, 202302480);
                Aluno aluno4 = new Aluno("Pedro", 7, 202302481);
                Aluno aluno5 = new Aluno("Ana", 6, 202302482);
                Aluno aluno6 = new Aluno("Lucas", 10, 202302483);
                Aluno aluno7 = new Aluno("Luiza", 9, 202302484);
                Aluno aluno8 = new Aluno("Carlos", 8, 202302485);
                Aluno aluno9 = new Aluno("Mariana", 7, 202302486);
                Aluno aluno10 = new Aluno("Roberto", 6, 202302487);
                Pauta novaPauta = new Pauta();
                novaPauta.addAlunos(aluno10);
                novaPauta.addAlunos(aluno9);
                novaPauta.addAlunos(aluno8);
                novaPauta.addAlunos(aluno7);
                novaPauta.addAlunos(aluno6);
                novaPauta.addAlunos(aluno5);
                novaPauta.addAlunos(aluno4);
                novaPauta.addAlunos(aluno3);
                novaPauta.addAlunos(aluno2);
                novaPauta.addAlunos(aluno1);
                novaPauta.verificaStatus();
            }
            catch (NotProvaFinalException ex)
            {
                Console.WriteLine("Alguém se ferrou...\n");
            }
            finally 
            {
                Console.WriteLine("Tudo certo por aqui!\n");
            }

        }
    }
}