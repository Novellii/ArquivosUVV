﻿using Microsoft.Data.SqlClient;

namespace SQL2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            SqlConnection connection =
            connection = new("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=RestauranteUVV;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");
            
            connection.Open();

            Console.WriteLine("Conexão OK\n");

            Console.WriteLine("Salvando no Banco de Dados\n");

            var insertCmd = connection.CreateCommand();
            insertCmd.CommandText = "Insert INTO Cursos (Nome, Categoria, Periodo) VALUES (@nome, @categoria, @periodo)";

            var paramNome = new SqlParameter("nome", "Estrutura de Dados");
            insertCmd.Parameters.Add(paramNome);

            var paramCategoria = new SqlParameter("categoria", "Ciência da Computação");
            insertCmd.Parameters.Add(paramCategoria);

            var paramPeriodo = new SqlParameter("periodo", "4");
            insertCmd.Parameters.Add(paramPeriodo);
            
            insertCmd.ExecuteNonQuery();

            connection.Close();
        }
    }
}
