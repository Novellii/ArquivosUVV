﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dia22_08
{
    internal interface FlyinhTransport
    {
        public void Voar(String Origem, String Destino, int Passageiros);

    }
}
