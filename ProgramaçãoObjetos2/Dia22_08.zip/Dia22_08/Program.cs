﻿using System.Security.Cryptography.X509Certificates;

namespace Dia22_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*Airport airport = new Airport();
            Helicopter helicopter = new Helicopter();
            Airplane airplane = new Airplane();
            Domesticated_Gryphon domesticated_Gryphon = new Domesticated_Gryphon();

            airport.aceitarVoo(helicopter, "Camimbé", "Mato Grosso", 6);
            airport.aceitarVoo(airplane, "Camimbé", "Mato Grosso", 6);
            airport.Limpar();
            domesticated_Gryphon.Voar("São Paulo", "Mato Grosso", 2);*/

        }
    }
}
