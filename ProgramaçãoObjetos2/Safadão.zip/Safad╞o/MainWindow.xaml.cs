﻿using Safadão.Classes;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Safadão
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        BindingList<Capivaras> listCapivaras;
        public MainWindow()
        {
            this.listCapivaras = new BindingList<Capivaras>();
            FormularioCapivaras.ItemsSource = listCapivaras;
            InitializeComponent();
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void HNNN(object sender, RoutedEventArgs e)
        {
            Capivaras cp = new Capivaras(NomeCapivaras.Text, int.Parse(IdadeCapivara.Text), float.Parse(PesoCapivara.Text));
            listCapivaras.Add(cp);
        }
    }
}