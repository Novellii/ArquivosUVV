﻿namespace Formulario
{
    internal class ItemsSource
    {
    }
}