﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using Exercício_Página_10.Classes;

namespace Exercício_Página_10
{
    public partial class MainWindow : Window
    {
        BindingList<Classes.Cliente> ListaClientes = new BindingList<Classes.Cliente>();
        public MainWindow()
        {
            InitializeComponent();
            criadouroPutas(1000);
            Formulario.ItemsSource = ListaClientes;
        }

        private void criadouroPutas(int x)
        {
            Random rnd = new Random();
            for (int i = 0; i < x;  i++)
            {
                int id = rnd.Next(1,999);
                Cliente c1 = new Cliente(id, " ");
                ListaClientes.Add(c1);
            }
        }

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void PesquisarPessoa(object sender, RoutedEventArgs e)
        {
            String selecionado = CaixaSelecao.Text;
            String conteudo = Conteudo.Text;
            BindingList<Classes.Cliente> ResultadosFiltrados = new BindingList<Classes.Cliente>();
            if (selecionado == "Id")
            {
                foreach (var cliente in ListaClientes)
                {
                    if (cliente.IdCliente == int.Parse(conteudo))
                    {
                        ResultadosFiltrados.Add(cliente);
                    }
                }
            }
            if (selecionado == "Nome")
            {
                foreach (var cliente in ListaClientes)
                {
                    if (cliente.Nome == conteudo)
                    {
                        ResultadosFiltrados.Add(cliente);
                    }
                }
            }
            Formulario.ItemsSource = ResultadosFiltrados;
        }

        private void Formulario_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}