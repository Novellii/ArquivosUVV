﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_Página_10.Classes
{
    internal class Cliente
    {
        public int IdCliente { get; set; }
        public String Nome { get; set; }
        public Cliente(int IdCliente, String Nome)
        {
            this.IdCliente = IdCliente;
            this.Nome = Nome;
        }
    }
}
