﻿using Microsoft.Data.SqlClient;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProjetoModelagem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection? conexao = null;
        public MainWindow()
        {
            InitializeComponent();

            string URL = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Empregado;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False";
            try
            {
                conexao = new(URL);
                conexao.Open();
                MessageBox.Show("OK");
            }
            catch (Exception ex)
            {
                MessageBox.Show("NOT OK");
            }

        }

        private void SalvarButton(object sender, RoutedEventArgs e)
        {
            if (MatriculaText.Text != "")
            {
                MessageBox.Show("Erro! Matrícula não pode ser preenchida!");
            } else if (CPFText.Text == "" || NomeText.Text == "" || EnderecoText.Text == "")
            {
                MessageBox.Show("Erro! Todos os campos devem ser Preenchidos!");
            }
            else
            {
                Empregado empregado = new Empregado(CPFText.Text, NomeText.Text, EnderecoText.Text);
                Empregado.Salvar(empregado, conexao);
                MessageBox.Show("Empregado Salvo!");
            }
        }

        private void PesquisarButton(object sender, RoutedEventArgs e)
        {

        }

        private void ExcluirButton(object sender, RoutedEventArgs e)
        {

        }

        private void LimparButton(object sender, RoutedEventArgs e)
        {

        }
    }
}