﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ProjetoModelagem
{
    class Empregado
    {
        public int matricula { get; set; }
        public string cpf { get; set; }
        public string nome { get; set; }
        public string endereco { get; set; }

        public Empregado(string cpf, string nome, string endereco)
        {
            this.cpf = cpf;
            this.nome = nome;
            this.endereco = endereco;
        }

        public static void Salvar(Empregado empregado, SqlConnection conexao)
        {
            MessageBox.Show(" == Salvando o Autor == ");

            var Cmd = conexao.CreateCommand();
            Cmd.CommandText = "INSERT INTO Empregado (nome, cpf, endereco) VALUES (@nome) (@cpf) (@endereco)";

            var param = new SqlParameter("nome", empregado.nome);
            Cmd.Parameters.Add(param);

            Cmd.Parameters.Add(new SqlParameter("cpf", empregado.cpf));
            Cmd.Parameters.Add(new SqlParameter("endereco", empregado.endereco));


            Cmd.ExecuteNonQuery();
        }

    }
}
