# mew.py

from app import app

#   Dar as Permissões:  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
#   Ativar o Server:    .\mew\scripts\activate
#   Rodar o Flask:      set FLASK_APP=mew.py
#   Flask é a biblioteca que roda o Servidor.
#   Rodar o Servidor:   flask run

#   Rodar o Servidor com Debug:   flask run --debug
#   Ligar Debug:                  $ENV:FLASK_DEBUG=1
#   Desligar Debug:               $ENV:FLASK_DEBUG=0