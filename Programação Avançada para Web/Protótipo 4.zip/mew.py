# mew.py

from app import app

#   Dar as Permissões:  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
#   Ativar o Server:    .\mew\scripts\activate
#   Rodar o Flask:      set FLASK_APP=mew.py
#   Flask é a biblioteca que roda o Servidor.
#   Rodar o Servidor:   flask run
#   Ligar Debug:        $ENV:FLASK_DEBUG=1