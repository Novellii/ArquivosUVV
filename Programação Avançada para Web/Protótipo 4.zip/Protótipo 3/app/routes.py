# app/routes.py

from flask import render_template
from app import app

@app.route('/')
@app.route('/index')

def index():
    user = {'username' : 'Samira'}
    posts = [
        {
            'author' : {'username' : 'Chocolate'},
            'body' : 'Está muito caro!'
        },
        {
            'author' : {'username' : 'Jujuba'},
            'body' : 'Está barato!'
        }
    ]
    return render_template('index.html', title="Home", user=user, posts=posts)