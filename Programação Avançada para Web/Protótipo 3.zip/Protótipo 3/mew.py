# mew.py

from app import app

#   .\mew\scripts\activate
#   set FLASK_APP=mew.py
#   flask run