from numpy import array, linalg

#augMat = [
#    [3,2,-4,3],
#    [2,3,3,15],
#    [5,-3,1,14]
#    ] 

#A = array([
#    [3, 2, -4],
#    [2, 3, 3],
#    [5, -3, 1]
#    ])
#b = array([3,15,14])

#A = array([
#    [0, 2, 0, 1],
#    [2, 2, 3, 2],
#    [4, -3, 0, 1],
#    [6, 1, -6, 5]
#    ])
#b = array([0, -2, -7, 6])

#A = array([
#    [-1, 1, 2],
#    [1, 2, 1],
#    [-2, -1, 1],
#    ])
#b = array([0, 6, -6])

A = array([
    [2, 3],
    [4, -1],
    ])
b = array([5, 7])

print("Matriz A:")
print(A)
print("\nMatriz B")
print(b)

print('\nSolution:')
try:
    solution = linalg.solve(A,b)
    print(solution)
except linalg.LinAlgError:
    print("\nLinalgError: Matriz Singular")