from scipy import linalg

#augMat = [
#    [3,2,-4,3],
#    [2,3,3,15],
#    [5,-3,1,14]
#    ] 

##A = array([
##    [3, 2, -4],
##    [2, 3, 3],
##    [5, -3, 1]
##    ])
##b = array([3,15,14])

#A = [
#    [0, 2, 0, 1],
#    [2, 2, 3, 2],
#    [4, -3, 0, 1],
#    [6, 1, -6, 5]
#    ]
#b = [0, -2, -7, 6]

A = [
    [-1,  1,  2],
    [ 1,  2,  1],
    [-2, -1,  1],
    ]
b = [0, 6, -6]


print("Matriz A:")
print(A)
print("\nMatriz B")
print(b)


print('\nSolution:')
try:
    solution = linalg.solve(A,b)
    print(solution)
except linalg.LinAlgError:
    print("\nLinalgError: Matriz Singular")