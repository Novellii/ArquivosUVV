from sympy import Matrix, simplify

#augMat = Matrix([
#    [3,  2, -4,  3],
#    [2,  3,  3,  15],
#    [5, -3,  1,  14]
#    ])

#augMat = Matrix([
#    [1, -1,  4, -5],
#    [3,  0,  1,  0],
#    [-1, 1, -4,  20]
#    ])

#augMat = Matrix([
#    [-1,  1,  2,  0],
#    [ 1,  2,  1,  6],
#    [-2, -1,  1, -6]
#])

augMat = Matrix([
    [ 2,  3, 5],
    [ 4, -1,  7]
])

print(augMat)



print('\nSolution:')
solution = augMat.rref()
print(solution)
simplify(solution)
print(solution)